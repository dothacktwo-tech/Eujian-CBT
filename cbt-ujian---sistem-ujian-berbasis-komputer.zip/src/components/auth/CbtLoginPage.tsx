import React, { useState } from 'react';
import { User, Lock, Eye, EyeOff, Info, School, Loader2, Sparkles, GraduationCap, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { AppSettings } from '../../types';
import { toast } from '../ui/Toast';

interface CbtLoginPageProps {
  initialRole: 'siswa' | 'admin';
  onSwitchRole: (newRole: 'siswa' | 'admin') => void;
  overrideSettings?: AppSettings;
  isEmbeddedPreview?: boolean;
}

export const CbtLoginPage: React.FC<CbtLoginPageProps> = ({ initialRole, onSwitchRole, overrideSettings, isEmbeddedPreview = false }) => {
  const { login, settings } = useAuth();
  const [role, setRole] = useState<'siswa' | 'admin'>(initialRole);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const effectiveSettings = overrideSettings || settings;

  const schoolName = effectiveSettings?.school_name || 'SMA Negeri 1 Lumbung';
  const schoolShortName = effectiveSettings?.school_short_name || 'SMAN 1 Lumbung';
  const schoolLogoUrl = effectiveSettings?.school_logo_url || effectiveSettings?.school_logo || '';
  const loginIllustrationUrl = effectiveSettings?.login_illustration_url || effectiveSettings?.login_image_url || '';
  const loginTitle = effectiveSettings?.login_title || 'Login Ujian CBT';
  const loginSubtitle = effectiveSettings?.login_subtitle || schoolName;
  const loginDescription = effectiveSettings?.login_description || 'Silakan masuk untuk mengikuti ujian.';
  const loginButtonText = effectiveSettings?.login_button_text || 'MASUK KE UJIAN';

  const primaryColor = effectiveSettings?.primary_color || '#FFB646';
  const buttonColor = effectiveSettings?.button_color || '#6097EA';
  const backgroundColor = effectiveSettings?.background_color || '#EAF2FF';

  const illustrationPosition = effectiveSettings?.illustration_position || 'center';
  const illustrationSize = effectiveSettings?.illustration_size !== undefined ? Number(effectiveSettings.illustration_size) : 100;
  const illustrationFit = effectiveSettings?.illustration_fit || 'contain';

  const handleRoleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selected = e.target.value as 'siswa' | 'admin';
    setRole(selected);
    setError('');
    onSwitchRole(selected);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setError('Silakan lengkapi username dan password.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const res = await login(username.trim(), password.trim());
      if (res.success) {
        if (role === 'admin' && res.role !== 'admin') {
          setError('Akun ini terdaftar sebagai Siswa. Mengarahkan ke Portal Siswa...');
          toast.info('Akun siswa terdeteksi.');
          setTimeout(() => {
            onSwitchRole('siswa');
          }, 800);
        } else if (role === 'siswa' && res.role === 'admin') {
          toast.success('Login Admin berhasil!');
        } else {
          toast.success('Login berhasil! Selamat datang.');
        }
      } else {
        setError(res.message || 'Login gagal. Periksa username dan password Anda.');
      }
    } catch (err: any) {
      setError(err.message || 'Terjadi gangguan jaringan.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = (e: React.MouseEvent) => {
    e.preventDefault();
    toast.info('Silakan hubungi proktor atau administrator sekolah untuk mereset password.');
  };

  const bgType = settings?.login_bg_type || 'default';
  const bgUrl = settings?.login_bg_url;
  const bgOverlayOpacity = settings?.login_bg_overlay || '0.4';

  const getWrapperClass = () => {
    if (bgType === 'dark_theme') return 'min-h-screen bg-slate-950 text-slate-100 font-sans relative flex items-center justify-center p-4 sm:p-6 overflow-x-hidden';
    if (bgType === 'school_gradient') return 'min-h-screen bg-gradient-to-br from-indigo-950 via-slate-900 to-amber-950 text-slate-100 font-sans relative flex items-center justify-center p-4 sm:p-6 overflow-x-hidden';
    return 'min-h-screen font-sans relative flex items-center justify-center p-4 sm:p-6 overflow-x-hidden';
  };

  return (
    <div className={getWrapperClass()} style={{ backgroundColor: bgType === 'default' ? backgroundColor : undefined }}>
      {/* ================= BACKGROUND CUSTOMIZATION & DECORATIONS ================= */}
      {bgType === 'custom_bg' && bgUrl ? (
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
          <img
            src={bgUrl}
            alt="Background Login Sekolah"
            className="w-full h-full object-cover"
          />
          <div
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px]"
            style={{ opacity: parseFloat(bgOverlayOpacity) || 0.4 }}
          />
        </div>
      ) : (
        <div className="fixed inset-0 overflow-hidden pointer-events-none">
          {/* Top Left Blob */}
          <div className="absolute rounded-full opacity-65 w-[350px] h-[350px] bg-[#9dbced] -top-32 -left-32" />

          {/* Top Right Blob */}
          <div className="absolute rounded-full opacity-65 w-[450px] h-[450px] bg-[#6d91dc] -top-40 -right-20" />

          {/* Bottom Left Blob */}
          <div className="absolute rounded-full opacity-65 w-[300px] h-[300px] bg-[#7198e1] -bottom-20 -left-20" />

          {/* Bottom Right Blob */}
          <div className="absolute rounded-full opacity-65 w-[420px] h-[420px] bg-[#9cbbe9] -bottom-40 -right-24" />

          {/* Decorative Circles */}
          <div className="absolute w-[500px] h-[500px] border-2 border-white/35 rounded-full -top-40 left-[22%]" />
          <div className="absolute w-[500px] h-[500px] border-2 border-white/35 rounded-full -bottom-64 left-[40%]" />

          {/* Gradient Accent Lines */}
          <div className="absolute top-0 left-[48%] w-[2px] h-[400px] bg-gradient-to-b from-transparent via-[#f6b94b] to-transparent rotate-[12deg] opacity-60" />
          <div className="absolute bottom-0 left-[25%] w-[2px] h-[500px] bg-gradient-to-t from-transparent via-[#f6b94b] to-transparent rotate-[65deg] opacity-50" />
        </div>
      )}

      {/* ================= MAIN CONTAINER ================= */}
      <main className="relative z-10 w-full max-w-[1150px] min-h-[640px] bg-white rounded-[20px] shadow-[0_25px_70px_rgba(37,64,110,.25)] overflow-hidden flex flex-col lg:flex-row my-auto">
        {/* ================= LEFT PANEL ================= */}
        <section
          className="lg:w-1/2 relative overflow-hidden flex flex-col items-center justify-center px-6 sm:px-8 py-10 sm:py-12 text-white"
          style={{ backgroundColor: primaryColor }}
        >
          {/* Background Decorative Circles */}
          <div className="absolute w-[500px] h-[500px] rounded-full bg-white/10 opacity-60 top-[60px] left-1/2 -translate-x-1/2 pointer-events-none" />
          <div className="absolute w-[380px] h-[380px] rounded-full border-[2px] border-white/20 top-[120px] left-1/2 -translate-x-1/2 pointer-events-none" />

          {/* Logo / Vector Illustration Circle */}
          <div className="relative z-10 mb-5">
            <div className="w-[220px] h-[220px] sm:w-[280px] sm:h-[280px] md:w-[320px] md:h-[320px] rounded-full bg-black/10 flex items-center justify-center overflow-hidden shadow-inner border-4 border-white/30 relative">
              {loginIllustrationUrl ? (
                <img
                  src={loginIllustrationUrl}
                  alt="Ilustrasi Login"
                  className="w-full h-full rounded-full transition-all duration-300"
                  style={{
                    objectFit: illustrationFit,
                    transform: `scale(${illustrationSize / 100})`,
                    objectPosition: illustrationPosition === 'top' ? 'top' : illustrationPosition === 'bottom' ? 'bottom' : 'center',
                  }}
                  onError={(e) => {
                    (e.currentTarget as HTMLElement).style.display = 'none';
                  }}
                />
              ) : settings?.login_image_type === 'custom_url' && settings?.login_image_url ? (
                <img
                  src={settings.login_image_url}
                  alt="Hero Login"
                  className="w-full h-full object-cover rounded-full"
                />
              ) : settings?.login_image_type === 'lucide_minimal' ? (
                <div className="w-full h-full bg-white/10 flex flex-col items-center justify-center p-6 text-center">
                  <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-white text-indigo-600 flex items-center justify-center shadow-2xl mb-3">
                    {schoolLogoUrl ? (
                      <img src={schoolLogoUrl} alt="Logo" className="w-20 h-20 object-contain" />
                    ) : (
                      <School className="w-14 h-14" />
                    )}
                  </div>
                  <p className="text-xl font-black text-white tracking-wide uppercase truncate max-w-[240px] drop-shadow-sm">
                    {schoolShortName || schoolName}
                  </p>
                  <span className="text-xs text-slate-900 font-bold px-3 py-1 rounded-full bg-white/90 shadow-sm mt-1">
                    CBT SERVER
                  </span>
                </div>
              ) : (
                /* Default Waving Student SVG */
                <svg viewBox="0 0 400 400" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
                  <g transform="translate(45, 55)">
                    <path
                      d="M 65 0 C 100 0, 125 22, 125 50 C 125 78, 100 95, 65 95 C 55 95, 45 92, 35 88 L 10 98 L 18 78 C 7 70, 5 60, 5 50 C 5 22, 30 0, 65 0 Z"
                      fill="#ffd43f"
                    />
                    <text
                      x="62"
                      y="45"
                      fontSize="24"
                      fill="#ffffff"
                      fontWeight="800"
                      fontStyle="italic"
                      textAnchor="middle"
                    >
                      hello
                    </text>
                    <text
                      x="62"
                      y="68"
                      fontSize="16"
                      fill="#3b2b00"
                      fontWeight="800"
                      textAnchor="middle"
                    >
                      CBT!
                    </text>
                  </g>
                  <circle cx="200" cy="140" r="58" fill="#ffd0ca" />
                  <circle cx="170" cy="155" r="12" fill="#ffb0b0" opacity="0.6" />
                  <circle cx="230" cy="155" r="12" fill="#ffb0b0" opacity="0.6" />
                  <path d="M 197 148 C 197 152, 203 152, 203 148" stroke="#e08078" strokeWidth="2.5" fill="none" strokeLinecap="round" />
                  <ellipse cx="178" cy="138" rx="5" ry="6" fill="#202020" />
                  <ellipse cx="222" cy="138" rx="5" ry="6" fill="#202020" />
                  <path d="M 188 165 Q 200 176 212 165" stroke="#d55860" strokeWidth="3.5" fill="none" strokeLinecap="round" />
                  <path
                    d="M 142 135 C 138 80, 180 62, 205 70 C 235 55, 265 80, 258 130 C 248 115, 235 110, 218 118 C 200 125, 175 110, 142 135 Z"
                    fill="#2b201c"
                  />
                  <rect x="187" y="185" width="26" height="30" rx="8" fill="#f4b3a9" />
                  <path
                    d="M 90 380 L 115 240 C 135 220, 165 210, 200 210 C 235 210, 265 220, 285 240 L 310 380 Z"
                    fill="#538bf3"
                  />
                  <polygon points="152,212 195,260 170,260 135,225" fill="#ffffff" />
                  <polygon points="248,212 205,260 230,260 265,225" fill="#ffffff" />
                  <polygon points="195,260 205,260 200,270" fill="#e8f0fe" />
                  <circle cx="200" cy="235" r="3" fill="#d49b00" />
                  <circle cx="200" cy="248" r="3" fill="#d49b00" />
                  <path d="M 140 270 Q 142 320 145 360" stroke="#4077e0" strokeWidth="3" fill="none" />
                  <path d="M 280 235 L 320 370" fill="#538bf3" />
                  <path d="M 280 235 L 290 320" stroke="#4077e0" strokeWidth="2.5" fill="none" />
                  <g transform="translate(280, 140)">
                    <path
                      d="M 0 100 C 10 60, 25 30, 40 10 C 48 5, 62 10, 60 25 L 45 80 L 25 105 Z"
                      fill="#538bf3"
                    />
                    <path d="M 35 15 L 60 22" stroke="#d49b00" strokeWidth="4" strokeLinecap="round" />
                    <path
                      d="M 38 12 C 35 -10, 48 -25, 52 -25 C 57 -25, 58 -10, 56 8 M 52 5 C 52 -18, 65 -28, 70 -26 C 75 -24, 72 -5, 68 12 M 65 10 C 68 -12, 80 -18, 83 -15 C 87 -12, 82 5, 76 18 M 74 18 C 80 5, 92 -2, 95 3 C 98 8, 88 22, 80 28 C 72 35, 52 40, 42 22 Z"
                      fill="#ffd0ca"
                    />
                  </g>
                </svg>
              )}
            </div>
          </div>

          {/* Left Title */}
          <div className="relative z-10 text-center text-white max-w-[520px]">
            <div className="flex items-center justify-center gap-3 mb-3">
              {/* School Logo */}
              <div className="w-11 h-11 bg-white rounded-full flex items-center justify-center text-indigo-600 font-extrabold text-xs shadow-md shrink-0 overflow-hidden">
                {schoolLogoUrl ? (
                  <img src={schoolLogoUrl} alt="Logo" className="w-full h-full object-contain p-1 rounded-full" />
                ) : (
                  <School className="w-6 h-6 text-indigo-600" />
                )}
              </div>

              <div className="text-left leading-tight">
                <p className="text-xs font-semibold tracking-wide uppercase opacity-90">PORTAL RESMI</p>
                <p className="text-lg font-black tracking-wide truncate max-w-[280px]">{schoolShortName || schoolName}</p>
              </div>
            </div>

            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight mb-2">{loginTitle}</h1>

            <p className="text-xs sm:text-sm leading-relaxed text-white/90 max-w-[420px] mx-auto font-medium">
              {loginDescription}
            </p>
          </div>
        </section>

        {/* ================= RIGHT PANEL ================= */}
        <section className="lg:w-1/2 bg-[#fffdf8] px-6 sm:px-12 md:px-14 lg:px-16 py-10 sm:py-12 flex items-center">
          <div className="w-full max-w-[420px] mx-auto">
            {/* Heading */}
            <div className="text-center mb-8">
              <p className="text-xs font-bold tracking-widest uppercase text-amber-600 mb-2">{schoolShortName || schoolName}</p>

              <h2 className="text-2xl sm:text-3xl font-black text-slate-800 mb-2">{loginTitle}</h2>

              <p className="text-[#64748b] text-xs sm:text-sm">{loginDescription}</p>
            </div>

            {/* Error Notification */}
            {error && (
              <div className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold leading-relaxed animate-shake">
                {error}
              </div>
            )}

            {/* FORM OR DIV PREVIEW */}
            {isEmbeddedPreview ? (
              <div className="space-y-4">
                {/* Role Select */}
                <div>
                  <label className="block text-xs sm:text-sm font-semibold text-[#334155] mb-2">
                    Login sebagai
                  </label>
                  <select
                    id="role-preview"
                    value={role}
                    onChange={handleRoleSelectChange}
                    className="w-full h-[48px] sm:h-[52px] rounded-xl border border-[#d7e0ef] bg-white px-4 text-[#334155] text-xs sm:text-sm font-medium outline-none cursor-pointer shadow-xs"
                  >
                    <option value="siswa">Siswa</option>
                    <option value="admin">Admin / Proktor</option>
                  </select>
                </div>

                {/* Username Input */}
                <div>
                  <label className="block text-xs sm:text-sm font-semibold text-[#334155] mb-2">
                    {role === 'siswa' ? 'NISN / Username' : 'Username Admin'}
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#7da7df]">
                      <User className="w-5 h-5" />
                    </span>
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder={role === 'siswa' ? 'Masukkan NISN atau username' : 'Masukkan username admin'}
                      className="w-full h-[48px] sm:h-[52px] rounded-xl border border-[#d7e0ef] bg-white pl-12 pr-4 text-xs sm:text-sm text-[#334155] outline-none shadow-xs"
                    />
                  </div>
                </div>

                {/* Password Input */}
                <div>
                  <label className="block text-xs sm:text-sm font-semibold text-[#334155] mb-2">
                    Password
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#7da7df]">
                      <Lock className="w-5 h-5" />
                    </span>
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Masukkan password"
                      className="w-full h-[48px] sm:h-[52px] rounded-xl border border-[#d7e0ef] bg-white pl-12 pr-12 text-xs sm:text-sm text-[#334155] outline-none shadow-xs"
                    />
                  </div>
                </div>

                {/* Login Button */}
                <button
                  type="button"
                  style={{ backgroundColor: buttonColor, backgroundImage: 'none' }}
                  className="w-full h-[52px] sm:h-[56px] rounded-xl mt-3 text-white font-bold tracking-wide shadow-md flex items-center justify-center gap-2 text-xs sm:text-sm cursor-pointer"
                >
                  <span>{loginButtonText || 'MASUK KE UJIAN'}</span>
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Role Select */}
                <div>
                  <label className="block text-xs sm:text-sm font-semibold text-[#334155] mb-2">
                    Login sebagai
                  </label>

                  <select
                    id="role"
                    value={role}
                    onChange={handleRoleSelectChange}
                    className="w-full h-[52px] rounded-xl border border-[#d7e0ef] bg-white px-4 text-[#334155] text-sm font-medium outline-none transition focus:border-[#6fa7f7] focus:ring-4 focus:ring-blue-500/10 cursor-pointer shadow-xs"
                  >
                    <option value="siswa">Siswa</option>
                    <option value="admin">Admin / Proktor</option>
                  </select>
                </div>

                {/* Username Input */}
                <div>
                  <label htmlFor="username" className="block text-xs sm:text-sm font-semibold text-[#334155] mb-2">
                    {role === 'siswa' ? 'NISN / Username' : 'Username Admin'}
                  </label>

                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#7da7df]">
                      <User className="w-5 h-5" />
                    </span>

                    <input
                      type="text"
                      id="username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder={role === 'siswa' ? 'Masukkan NISN atau username' : 'Masukkan username admin'}
                      className="w-full h-[52px] rounded-xl border border-[#d7e0ef] bg-white pl-12 pr-4 text-sm text-[#334155] outline-none transition focus:border-[#6fa7f7] focus:ring-4 focus:ring-blue-500/10 shadow-xs"
                      required
                      autoFocus
                    />
                  </div>
                </div>

                {/* Password Input */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label htmlFor="password" className="text-xs sm:text-sm font-semibold text-[#334155]">
                      Password
                    </label>
                  </div>

                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#7da7df]">
                      <Lock className="w-5 h-5" />
                    </span>

                    <input
                      type={showPassword ? 'text' : 'password'}
                      id="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Masukkan password"
                      className="w-full h-[52px] rounded-xl border border-[#d7e0ef] bg-white pl-12 pr-12 text-sm text-[#334155] outline-none transition focus:border-[#6fa7f7] focus:ring-4 focus:ring-blue-500/10 shadow-xs"
                      required
                    />

                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-[#8da5c4] hover:text-[#4d83c9] transition-colors p-1"
                      title={showPassword ? 'Sembunyikan password' : 'Tampilkan password'}
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Remember & Forgot Password */}
                <div className="flex items-center justify-between pt-1 text-xs sm:text-sm">
                  <label className="flex items-center gap-2 cursor-pointer text-[#64748b] select-none">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="w-4 h-4 rounded border-gray-300 text-blue-500 focus:ring-blue-400 cursor-pointer"
                    />
                    <span>Ingat saya</span>
                  </label>

                  <a
                    href="#forgot"
                    onClick={handleForgotPassword}
                    className="font-semibold text-[#4f8fe9] hover:text-[#2874dc] transition-colors"
                  >
                    Lupa password?
                  </a>
                </div>

                {/* Login Button */}
                <button
                  type="submit"
                  disabled={loading}
                  style={{ backgroundColor: buttonColor, backgroundImage: 'none' }}
                  className="w-full h-[56px] rounded-xl mt-3 text-white font-bold tracking-wide shadow-md hover:brightness-105 active:translate-y-0 disabled:opacity-75 transition duration-150 flex items-center justify-center gap-2 text-sm cursor-pointer"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>MEMPROSES...</span>
                    </>
                  ) : (
                    <span>{loginButtonText || 'MASUK KE UJIAN'}</span>
                  )}
                </button>
              </form>
            )}

            {/* Information Box */}
            <div className="mt-7 rounded-xl bg-[#eef6ff] border border-[#d8eaff] p-4 shadow-xs">
              <div className="flex gap-3 items-start">
                <div className="shrink-0 w-8 h-8 rounded-full bg-[#d8eaff] flex items-center justify-center text-[#478ce4]">
                  <Info className="w-4 h-4" />
                </div>

                <div>
                  <p className="text-xs sm:text-sm font-bold text-[#315f96]">Informasi Ujian</p>
                  <p className="text-xs text-[#64809f] leading-relaxed mt-0.5">
                    Pastikan NISN dan password yang digunakan sudah benar sebelum masuk ke ruang ujian.
                  </p>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="text-center mt-7 pt-2">
              <p className="text-xs text-[#94a3b8] font-medium">
                © {new Date().getFullYear()} {schoolName}
              </p>
              <p className="text-[11px] text-[#b0bac7] mt-0.5">Sistem Ujian Computer Based Test</p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};
