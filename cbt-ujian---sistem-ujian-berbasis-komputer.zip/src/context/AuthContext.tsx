import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, AppSettings } from '../types';
import { apiRequest, setStoredToken, getStoredToken } from '../services/api';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  settings: AppSettings;
  login: (username: string, password: string) => Promise<{ success: boolean; message?: string; role?: string }>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  refreshSettings: () => Promise<void>;
}

const defaultSettings: AppSettings = {
  school_name: 'SMA Negeri 1 Lumbung',
  school_short_name: 'SMAN 1 Lumbung',
  school_description: 'Sistem Computer Based Test',
  school_logo_url: '',
  academic_year: '2024/2025',
  login_title: 'Login Ujian CBT',
  login_subtitle: 'SMA Negeri 1 Lumbung',
  login_description: 'Silakan masuk untuk mengikuti ujian.',
  login_button_text: 'MASUK KE UJIAN',
  login_illustration_url: '',
  illustration_position: 'center',
  illustration_size: 100,
  illustration_fit: 'contain',
  primary_color: '#FFB646',
  button_color: '#6097EA',
  background_color: '#EAF2FF',
  allow_student_print_result: '1',
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);

  const fetchSettings = async () => {
    try {
      const res = await apiRequest<Record<string, string>>('/api/settings');
      if (res.success && res.data) {
        setSettings({
          school_name: res.data.school_name || defaultSettings.school_name,
          school_short_name: res.data.school_short_name || 'SMAN 1 Lumbung',
          school_description: res.data.school_description || 'Sistem Computer Based Test',
          school_logo_url: res.data.school_logo_url || res.data.school_logo || '',
          academic_year: res.data.academic_year || defaultSettings.academic_year,
          school_logo: res.data.school_logo || res.data.school_logo_url || '',
          default_shuffle_questions: res.data.default_shuffle_questions,
          default_shuffle_answers: res.data.default_shuffle_answers,
          default_show_score: res.data.default_show_score,
          login_title: res.data.login_title || 'Login Ujian CBT',
          login_subtitle: res.data.login_subtitle || res.data.school_name || 'SMA Negeri 1 Lumbung',
          login_description: res.data.login_description || 'Silakan masuk untuk mengikuti ujian.',
          login_button_text: res.data.login_button_text || 'MASUK KE UJIAN',
          login_illustration_url: res.data.login_illustration_url || res.data.login_image_url || '',
          illustration_position: (res.data.illustration_position as any) || 'center',
          illustration_size: res.data.illustration_size ? parseInt(res.data.illustration_size, 10) : 100,
          illustration_fit: (res.data.illustration_fit as any) || 'contain',
          primary_color: res.data.primary_color || '#FFB646',
          button_color: res.data.button_color || '#6097EA',
          background_color: res.data.background_color || '#EAF2FF',
          login_image_type: (res.data.login_image_type as any) || 'default_waving',
          login_image_url: res.data.login_image_url || res.data.login_illustration_url || '',
          login_bg_type: (res.data.login_bg_type as any) || 'default',
          login_bg_url: res.data.login_bg_url || '',
          login_bg_overlay: res.data.login_bg_overlay || '0.4',
          allow_student_print_result: res.data.allow_student_print_result !== '0' ? '1' : '0',
        });
      }
    } catch (e) {
      console.error('Error fetching settings:', e);
    }
  };

  const fetchUser = async () => {
    const token = getStoredToken();
    if (!token) {
      setUser(null);
      setLoading(false);
      return;
    }

    try {
      const res = await apiRequest<User>('/api/me');
      if (res.success && res.user) {
        setUser(res.user);
      } else {
        setStoredToken(null);
        setUser(null);
      }
    } catch (e) {
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
    fetchUser();
  }, []);

  const login = async (username: string, password: string) => {
    const res = await apiRequest('/api/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });

    if (res.success && res.token && res.user) {
      setStoredToken(res.token);
      setUser(res.user);
      return { success: true, role: res.user.role };
    }

    return { success: false, message: res.message || 'Login gagal.' };
  };

  const logout = async () => {
    try {
      await apiRequest('/api/logout', { method: 'POST' });
    } catch (e) {
      // ignore
    } finally {
      setStoredToken(null);
      setUser(null);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        settings,
        login,
        logout,
        refreshUser: fetchUser,
        refreshSettings: fetchSettings,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
