import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import { router, authMiddleware } from './server/routes.js';
import { getDb } from './server/db.js';
import { runSupabaseAutoMigration, pgConfig } from './server/pg.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  const isProd = process.env.NODE_ENV === 'production';

  // Initialize SQLite Database (Auto-ensures all schema tables & indexes exist)
  await getDb();
  console.log('[Database] Relational Database (SQLite/SQL.js) initialized, schema verified, and seeded.');

  // Auto-sync / Auto-create tables in Supabase if database password/connection configured
  if (process.env.SUPABASE_DB_PASSWORD || process.env.PGPASSWORD || process.env.DATABASE_URL) {
    runSupabaseAutoMigration()
      .then((migrationResult) => {
        if (migrationResult.success) {
          console.log('[Supabase Auto-Sync] Sukses: Seluruh tabel Supabase PostgreSQL telah otomatis dibuat dan diselaraskan.');
        } else {
          console.log('[Supabase Auto-Sync] Info:', migrationResult.message);
        }
      })
      .catch((err) => {
        console.warn('[Supabase Auto-Sync Notice] Migrasi otomatis ditunda:', err.message);
      });
  } else {
    console.log('[Supabase Auto-Sync] Siap. Eksekusi tabel otomatis dapat dipicu kapan saja dari Pengaturan atau dengan mengatur PGPASSWORD/SUPABASE_DB_PASSWORD.');
  }

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));
  app.use(cookieParser());
  app.use(authMiddleware);

  // Mount API Router
  app.use('/api', router);

  // Vite Dev Server or Production Static Files
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[CBT Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[Server Init Error]', err);
});
