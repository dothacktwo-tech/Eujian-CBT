import { createClient, SupabaseClient } from '@supabase/supabase-js';

const SUPABASE_URL =
  process.env.SUPABASE_URL || 'https://wpzvwwxnfurztyejkhsm.supabase.co';
const SUPABASE_KEY =
  process.env.SUPABASE_PUBLISHABLE_KEY ||
  process.env.SUPABASE_ANON_KEY ||
  'sb_publishable_CqxZWICgjXk9rXAM4sdFvA_MKLnJnHF';

let supabaseInstance: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient {
  if (!supabaseInstance) {
    supabaseInstance = createClient(SUPABASE_URL, SUPABASE_KEY, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });
  }
  return supabaseInstance;
}

export const supabaseConfig = {
  url: SUPABASE_URL,
  key: SUPABASE_KEY,
  host: 'db.wpzvwwxnfurztyejkhsm.supabase.co',
  port: 5432,
  database: 'postgres',
  user: 'postgres',
};
