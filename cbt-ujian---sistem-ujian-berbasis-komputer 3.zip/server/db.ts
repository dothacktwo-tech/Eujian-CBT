import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

let dbInstance: Database | null = null;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'cbt.sqlite');

export interface SqlDatabase {
  query<T = any>(sql: string, params?: any[]): T[];
  queryOne<T = any>(sql: string, params?: any[]): T | null;
  run(sql: string, params?: any[]): { changes: number; lastInsertRowid: number };
  transaction<T>(fn: () => T): T;
  exportBinary(): Uint8Array;
  persist(): void;
}

export async function getDb(): Promise<SqlDatabase> {
  if (dbInstance) {
    return createWrapper(dbInstance);
  }

  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  const SQL = await initSqlJs();
  let db: Database;

  if (fs.existsSync(DB_FILE)) {
    try {
      const fileBuffer = fs.readFileSync(DB_FILE);
      db = new SQL.Database(fileBuffer);
    } catch (err) {
      console.error('Error loading existing database file, creating fresh database:', err);
      db = new SQL.Database();
    }
  } else {
    db = new SQL.Database();
  }

  dbInstance = db;
  const wrapper = createWrapper(db);

  // Initialize schema
  const schemaPath = path.resolve(process.cwd(), 'server', 'schema.sql');
  if (fs.existsSync(schemaPath)) {
    const schemaSql = fs.readFileSync(schemaPath, 'utf8');
    db.run(schemaSql);

    // Auto-migrate new columns for questions
    try {
      const qCols = wrapper.query<any>("PRAGMA table_info(questions);");
      const colNames = qCols.map((c) => c.name);
      if (!colNames.includes('opsi_e')) {
        wrapper.run("ALTER TABLE questions ADD COLUMN opsi_e TEXT DEFAULT ''");
      }
      if (!colNames.includes('kategori')) {
        wrapper.run("ALTER TABLE questions ADD COLUMN kategori TEXT DEFAULT 'Umum'");
      }
      if (!colNames.includes('jumlah_opsi')) {
        wrapper.run("ALTER TABLE questions ADD COLUMN jumlah_opsi INTEGER DEFAULT 4");
      }
    } catch (err) {
      console.warn('Questions column migration notice:', err);
    }

    // Auto-migrate new columns for exam_participants
    try {
      const pCols = wrapper.query<any>("PRAGMA table_info(exam_participants);");
      const pColNames = pCols.map((c) => c.name);
      if (!pColNames.includes('last_heartbeat')) {
        wrapper.run("ALTER TABLE exam_participants ADD COLUMN last_heartbeat TEXT");
      }
      if (!pColNames.includes('current_question_index')) {
        wrapper.run("ALTER TABLE exam_participants ADD COLUMN current_question_index INTEGER DEFAULT 0");
      }
      if (!pColNames.includes('answered_count')) {
        wrapper.run("ALTER TABLE exam_participants ADD COLUMN answered_count INTEGER DEFAULT 0");
      }
      if (!pColNames.includes('ip_address')) {
        wrapper.run("ALTER TABLE exam_participants ADD COLUMN ip_address TEXT");
      }
    } catch (err) {
      console.warn('Exam participants column migration notice:', err);
    }
  }

  // Seed initial data if tables are empty
  await seedInitialData(wrapper);
  wrapper.persist();

  return wrapper;
}

function createWrapper(db: Database): SqlDatabase {
  let inTransaction = false;

  const persist = () => {
    if (inTransaction) return;
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const data = db.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(DB_FILE, buffer);
    } catch (err) {
      console.error('Failed to persist database to disk:', err);
    }
  };

  return {
    query<T = any>(sql: string, params: any[] = []): T[] {
      const stmt = db.prepare(sql);
      try {
        if (params && params.length > 0) {
          stmt.bind(params);
        }
        const results: T[] = [];
        while (stmt.step()) {
          results.push(stmt.getAsObject() as unknown as T);
        }
        return results;
      } finally {
        stmt.free();
      }
    },

    queryOne<T = any>(sql: string, params: any[] = []): T | null {
      const rows = this.query<T>(sql, params);
      return rows.length > 0 ? rows[0] : null;
    },

    run(sql: string, params: any[] = []): { changes: number; lastInsertRowid: number } {
      try {
        db.run(sql, params && params.length > 0 ? params : undefined);
        const changes = db.getRowsModified();
        if (!inTransaction) {
          persist();
        }
        return { changes, lastInsertRowid: 0 };
      } catch (err) {
        console.error('SQL Execution Error:', sql, params, err);
        throw err;
      }
    },

    transaction<T>(fn: () => T): T {
      if (inTransaction) {
        return fn();
      }
      inTransaction = true;
      try {
        db.run('BEGIN TRANSACTION;');
        const result = fn();
        db.run('COMMIT;');
        inTransaction = false;
        persist();
        return result;
      } catch (err) {
        try {
          db.run('ROLLBACK;');
        } catch (rbErr) {
          // Ignore rollback error if already aborted
        }
        inTransaction = false;
        throw err;
      }
    },

    exportBinary(): Uint8Array {
      return db.export();
    },

    persist,
  };
}

async function seedInitialData(db: SqlDatabase) {
  // Check if admin exists
  const admin = db.queryOne('SELECT id FROM users WHERE role = ?', ['admin']);
  const now = new Date().toISOString();

  if (!admin) {
    const adminPasswordHash = bcrypt.hashSync('admin123', 10);
    db.run(
      `INSERT INTO users (id, username, password_hash, role, name, created_at, updated_at) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      ['user-admin-1', 'admin', adminPasswordHash, 'admin', 'Administrator Utama', now, now]
    );

    // Initial Settings
    const defaultSettings: [string, string][] = [
      ['school_name', 'SMA Negeri 1 Nusantara'],
      ['academic_year', '2024/2025'],
      ['school_logo', ''],
      ['default_shuffle_questions', '0'],
      ['default_shuffle_answers', '0'],
      ['default_show_score', '1'],
    ];

    for (const [k, v] of defaultSettings) {
      db.run('INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, ?)', [k, v, now]);
    }

    // Seed Classes
    const classes = [
      { id: 'cls-1', nama_kelas: 'X IPA 1', tingkat: '10', tahun_ajaran: '2024/2025' },
      { id: 'cls-2', nama_kelas: 'X IPA 2', tingkat: '10', tahun_ajaran: '2024/2025' },
      { id: 'cls-3', nama_kelas: 'XI IPA 1', tingkat: '11', tahun_ajaran: '2024/2025' },
      { id: 'cls-4', nama_kelas: 'XII IPA 1', tingkat: '12', tahun_ajaran: '2024/2025' },
    ];

    for (const cls of classes) {
      db.run(
        `INSERT INTO classes (id, nama_kelas, tingkat, tahun_ajaran, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, 'aktif', ?, ?)`,
        [cls.id, cls.nama_kelas, cls.tingkat, cls.tahun_ajaran, now, now]
      );
    }

    // Seed Students
    const studentPasswordHash = bcrypt.hashSync('siswa123', 10);
    const students = [
      { id: 'std-1', nis: '1001', nama: 'Ahmad Fadillah', username: 'ahmad', class_id: 'cls-1' },
      { id: 'std-2', nis: '1002', nama: 'Budi Santoso', username: 'budi', class_id: 'cls-1' },
      { id: 'std-3', nis: '1003', nama: 'Citra Dewi Lestari', username: 'citra', class_id: 'cls-1' },
      { id: 'std-4', nis: '1004', nama: 'Dian Permata', username: 'dian', class_id: 'cls-1' },
      { id: 'std-5', nis: '1005', nama: 'Eko Prasetyo', username: 'eko', class_id: 'cls-1' },
      { id: 'std-6', nis: '1006', nama: 'Fajar Nugroho', username: 'fajar', class_id: 'cls-2' },
      { id: 'std-7', nis: '1007', nama: 'Gita Savitri', username: 'gita', class_id: 'cls-2' },
    ];

    for (const std of students) {
      db.run(
        `INSERT INTO students (id, nis, nama, username, password_hash, class_id, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, 'aktif', ?, ?)`,
        [std.id, std.nis, std.nama, std.username, studentPasswordHash, std.class_id, now, now]
      );
    }

    // Seed Question Banks
    const qb1Id = 'qb-mat-1';
    db.run(
      `INSERT INTO question_banks (id, nama_bank, mata_pelajaran, kelas_id, deskripsi, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, 'aktif', ?, ?)`,
      [qb1Id, 'Matematika Wajib - Aljabar & Eksponen', 'Matematika', 'cls-1', 'Bank Soal Ujian Tengah Semester Bab 1 & 2', now, now]
    );

    const questionsMat = [
      {
        id: 'q-mat-1',
        pertanyaan: 'Bentuk sederhana dari (2^3 * 2^4) / 2^2 adalah...',
        opsi_a: '2^5',
        opsi_b: '2^6',
        opsi_c: '2^7',
        opsi_d: '2^9',
        jawaban_benar: 'A',
        bobot: 1.0,
      },
      {
        id: 'q-mat-2',
        pertanyaan: 'Jika 3^(2x - 1) = 27, maka nilai x yang memenuhi adalah...',
        opsi_a: '1',
        opsi_b: '2',
        opsi_c: '3',
        opsi_d: '4',
        jawaban_benar: 'B',
        bobot: 1.0,
      },
      {
        id: 'q-mat-3',
        pertanyaan: 'Nilai dari ^2log 16 + ^3log 27 - ^5log 25 adalah...',
        opsi_a: '3',
        opsi_b: '4',
        opsi_c: '5',
        opsi_d: '6',
        jawaban_benar: 'C',
        bobot: 1.0,
      },
      {
        id: 'q-mat-4',
        pertanyaan: 'Himpunan penyelesaian dari persamaan kuadrat x^2 - 5x + 6 = 0 adalah...',
        opsi_a: '{1, 6}',
        opsi_b: '{-2, -3}',
        opsi_c: '{2, 3}',
        opsi_d: '{-1, -6}',
        jawaban_benar: 'C',
        bobot: 1.0,
      },
      {
        id: 'q-mat-5',
        pertanyaan: 'Grafik fungsi kuadrat f(x) = x^2 - 4x + 3 memotong sumbu Y di titik...',
        opsi_a: '(0, 3)',
        opsi_b: '(3, 0)',
        opsi_c: '(0, -3)',
        opsi_d: '(1, 0)',
        jawaban_benar: 'A',
        bobot: 1.0,
      },
    ];

    for (const q of questionsMat) {
      db.run(
        `INSERT INTO questions (id, question_bank_id, pertanyaan, opsi_a, opsi_b, opsi_c, opsi_d, jawaban_benar, bobot, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [q.id, qb1Id, q.pertanyaan, q.opsi_a, q.opsi_b, q.opsi_c, q.opsi_d, q.jawaban_benar, q.bobot, now, now]
      );
    }

    const qb2Id = 'qb-ind-1';
    db.run(
      `INSERT INTO question_banks (id, nama_bank, mata_pelajaran, kelas_id, deskripsi, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, 'aktif', ?, ?)`,
      [qb2Id, 'Bahasa Indonesia - Teks Laporan Hasil Observasi', 'Bahasa Indonesia', 'cls-1', 'Ujian Harian Bab Teks LHO', now, now]
    );

    const questionsInd = [
      {
        id: 'q-ind-1',
        pertanyaan: 'Teks yang berisi penjabaran umum mengenai sesuatu yang didasarkan pada hasil pengamatan disebut...',
        opsi_a: 'Teks Eksposisi',
        opsi_b: 'Teks Laporan Hasil Observasi',
        opsi_c: 'Teks Anekdot',
        opsi_d: 'Teks Negosiasi',
        jawaban_benar: 'B',
        bobot: 1.0,
      },
      {
        id: 'q-ind-2',
        pertanyaan: 'Ciri utama dari teks laporan hasil observasi adalah bersifat...',
        opsi_a: 'Subjektif dan imajinatif',
        opsi_b: 'Objektif, faktual, dan sistematis',
        opsi_c: 'Fiktif dan menghibur',
        opsi_d: 'Persuasif dan mengajak pembaca',
        jawaban_benar: 'B',
        bobot: 1.0,
      },
      {
        id: 'q-ind-3',
        pertanyaan: 'Struktur teks laporan hasil observasi yang benar adalah...',
        opsi_a: 'Pernyataan umum, deskripsi bagian, deskripsi manfaat',
        opsi_b: 'Orientasi, komplikasi, resolusi',
        opsi_c: 'Tesis, argumentasi, penegasan ulang',
        opsi_d: 'Abstraksi, orientasi, krisis, reaksi, koda',
        jawaban_benar: 'A',
        bobot: 1.0,
      },
    ];

    for (const q of questionsInd) {
      db.run(
        `INSERT INTO questions (id, question_bank_id, pertanyaan, opsi_a, opsi_b, opsi_c, opsi_d, jawaban_benar, bobot, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [q.id, qb2Id, q.pertanyaan, q.opsi_a, q.opsi_b, q.opsi_c, q.opsi_d, q.jawaban_benar, q.bobot, now, now]
      );
    }

    // Seed Sample Exam
    const today = new Date().toISOString().split('T')[0];
    const exam1Id = 'exam-1';
    const token1 = 'MAT101';

    db.run(
      `INSERT INTO exams (
        id, nama_ujian, mata_pelajaran, class_id, question_bank_id, tanggal, waktu_mulai, waktu_selesai,
        durasi_menit, token, shuffle_questions, shuffle_answers, tampilkan_nilai, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'aktif', ?, ?)`,
      [
        exam1Id,
        'Penilaian Harian Matematika Wajib',
        'Matematika',
        'cls-1',
        qb1Id,
        today,
        '07:00',
        '23:59',
        60,
        token1,
        1,
        1,
        1,
        now,
        now,
      ]
    );

    // Also register exam participants for all students in class cls-1
    const class1Students = db.query('SELECT id FROM students WHERE class_id = ?', ['cls-1']);
    for (const s of class1Students) {
      db.run(
        `INSERT INTO exam_participants (
          id, exam_id, student_id, status, score, total_questions, correct_answers, wrong_answers, created_at, updated_at
        ) VALUES (?, ?, ?, 'belum_mulai', 0, 0, 0, 0, ?, ?)`,
        [`part-${exam1Id}-${s.id}`, exam1Id, s.id, now, now]
      );
    }
  }
}
